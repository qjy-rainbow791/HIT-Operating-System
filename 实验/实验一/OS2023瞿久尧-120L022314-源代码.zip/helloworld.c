#include <stdio.h>
#include "syscall.h"

void test_syscall(const char* name,char* name_buf,int name_buf_size){
    int name_size=strlen(name)+1;
    int copied_size=0;

    if((copied_size=iam(name))!=name_size){
        printf("iam() error: %d was return, expected %d\n",copied_size,name_size);
        return;
    }

    if((copied_size=whoami(name_buf,name_buf_size))==-1){
        printf("whoami() error:insufficient buffer size\n");
        return;
    }

    printf("%s\n",name_buf);
}

int main(int argc, char **argv)
{    
    const int name_buf_size=50;
    char name_buf[name_buf_size];

    test_syscall("qu jiu yao",name_buf,name_buf_size);
    test_syscall("12345678901234567890123",name_buf,name_buf_size);
    test_syscall("123456789012345678901234",name_buf,name_buf_size);

    test_syscall("12345678901234567890123",name_buf,24);
    test_syscall("123456789012345678901234",name_buf,23);

    return 0;
}

